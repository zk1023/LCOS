# -*- coding: utf-8 -*-
import numpy as np
from scipy import sparse
from skmultilearn.dataset import load_dataset, save_to_arff, load_from_arff
from ormlsmote_class import Ormlsmote
import os
from label_correlation import *
import time
import copy


mapping = {'scene':scene_correlation,'yeast':yeast_correlation,'birds':birds_correlation,
           'enron':enron_correlation,'medical':medical_correlation,'bibtex':bibtex_correlation,
           'Corel5k':Corel5k_correlation,'flags':flags_correlation,'rcv1subset1':rcv1subset1_correlation,
           'rcv1subset2':rcv1subset2_correlation,'yahoo-Arts':yahoo_Arts_correlation,'yahoo-Education':yahoo_Education_correlation
           'chemistry': 50, 'chess':46, 'cooking': 50, 'philosophy':50}

resample_ra = 5
restresample_th = 0.2
Resample_rest_ratio = 1
ratio_Disjunction = 1

label_count_datasheet = {'birds':12,'scene':6,'enron':35,'yeast':14,'medical':14 ,
                         'bibtex':50 ,'Corel5k':50,'flags':7  ,'rcv1subset1':50 ,
                         'rcv1subset2':50 ,'yahoo-Arts':24 ,'yahoo-Education':27,
                         'chemistry': 50, 'chess':46, 'cooking': 50, 'philosophy':50}

dir_datasheet_upper = '../split_data/'
dir_save_upper = '../experiments/regroup/train data/'
splits_count = 1

for datasheet in label_count_datasheet.keys():
    dir_datasheet = os.path.join(dir_datasheet_upper, datasheet, datasheet + '.arff')
    # 加载数据集 X是数据集中的特征矩阵，y是标签矩阵
    if os.path.exists(dir_datasheet):
        X, y = load_from_arff(dir_datasheet, label_count_datasheet[datasheet])
    else:
        dir_datasheet_train = os.path.join(dir_datasheet_upper, datasheet, datasheet + '-train.arff')
        dir_datasheet_test = os.path.join(dir_datasheet_upper, datasheet, datasheet + '-test.arff')
        Xtrain, ytrain = load_from_arff(dir_datasheet_train, label_count_datasheet[datasheet])
        Xtest, ytest = load_from_arff(dir_datasheet_test, label_count_datasheet[datasheet])

        X, y = safe_vstack(Xtest, ytest, Xtrain, ytrain)
        # 需要保持默认的lil_matrix格式
        X = ensure_output_format(X, sparse_format='lil', require_dense=False, enforce_sparse=True)

    X, y = preprocess(X, y)  # 去除掉标签对应的样本个数少于10的样本;去除掉样本的标签全是0的样本
    # statistics_info(X, y)
    splits_count = 1
    # 1.根据SRN学习得到标签关联性
    W = np.array(mapping.get(datasheet))

    # 2.根据共有样本数统计得到的标签关联性
    # W=np.zeros([y_train.shape[1],y_train.shape[1]])
    # y_dense = copy.deepcopy(y_train)
    # y_dense = y_dense.todense()
    # for i in range(y_dense.shape[1]):
    #     for j in range(y_dense.shape[1]):
    #         W[i,j]=(y_dense[:,i] & y_dense[:,j]).sum(axis=0)[0,0] / (y_dense[:,i].sum(axis=0)[0,0])

    # 关联性min-max归一化
    maxElem = np.max(W)
    minElem = np.min(W)
    for row in range(len(W)):
        for col in range(len(W[0])):
            W[row][col] = (W[row][col] - minElem) / (maxElem - minElem)

    for experiment in range(2):
        # =============
        # =============
        # =============
        kf = KFold(n_splits=5, shuffle=True, random_state=experiment)
        kf.split(X, y)
        count = 0
        for train_index, test_index in kf.split(X, y):
            y_train, y_test = y[train_index], y[test_index]
            X_train, X_test = X[train_index], X[test_index]
            """our采样"""
            ORS_plus_ada_dj = Ormlsmote(resample_plus=True, resample_disjunction=True)
            X_resampled_plus_ada_dj, y_resampled_plus_ada_dj = ORS_plus_ada_dj.fit_resample(
                X_train, y_train, restresample_threshold=restresample_th, resample_ratio=resample_ra,
                resample_rest_ratio=Resample_rest_ratio, ratio_disjunction=ratio_Disjunction,
                ifcompare=False, label_correlation=W)

            """对照组"""
            ORS_plus_ada_dj_compare = Ormlsmote(resample_plus=True, resample_disjunction=True)
            X_resampled_plus_ada_dj_compare, y_resampled_plus_ada_dj_compare = ORS_plus_ada_dj_compare.fit_resample(
                X_train, y_train, restresample_threshold=restresample_th, resample_ratio=resample_ra,
                resample_rest_ratio=Resample_rest_ratio, ratio_disjunction=ratio_Disjunction,
                ifcompare=True, label_correlation=W)

            dir_save = dir_save_upper + datasheet
            if not os.path.exists(dir_save):
                os.makedirs(dir_save)
            dataname = datasheet + '_' + str(splits_count)
            label_location = 'end'
            save_sparse = True

            filepath = os.path.join(dir_save, dataname + 'trainRePlus' + '2.5dj.arff')
            save_to_arff(X_resampled_plus_ada_dj, y_resampled_plus_ada_dj,
                         label_location=label_location,
                         save_sparse=save_sparse, filename=filepath)

            filepath = os.path.join(dir_save, dataname + 'trainRePlus' + '2.5dj_compare.arff')
            save_to_arff(X_resampled_plus_ada_dj_compare, y_resampled_plus_ada_dj_compare,
                         label_location=label_location,
                         save_sparse=save_sparse, filename=filepath)
            splits_count += 1
