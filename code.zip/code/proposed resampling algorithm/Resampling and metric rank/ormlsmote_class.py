# -*- coding: utf-8 -*-
import copy
import numpy as np
from scipy import sparse
from ormlsmote_utils import ensure_output_format, safe_vstack
import gurobipy as gp
from gurobipy import GRB
from sklearn.utils import _safe_indexing
from sklearn.metrics.pairwise import pairwise_distances
from sklearn.neighbors import NearestNeighbors
from sklearn.utils import check_random_state
import pandas as pd


class Ormlsmote():

    def __init__(self, kn=5, knd=5, k1=5, k2=5, k3=5, k4=5, kr=5, Cth=3, n_jobs=24,
                 random_state=None, resample_plus=False,resample_disjunction=False):

        self.kn = kn
        self.knd = knd
        self.k1 = k1
        self.k2 = k2
        self.k3 = k3
        self.k4 = k4
        self.kr = kr
        self.Cth = Cth
        self.n_jobs = n_jobs
        self.random_state = random_state
        self.resample_plus = resample_plus
        self.resample_disjunction = resample_disjunction
        self.IBLbl=[]
        self.W=None  #标签关联性矩阵
        self.strong=None
        self._clean()

    def _clean(self):
        """Reset classifier internals before refitting"""

        '''类别情况统计信息'''
        self._label_count = None
        self._N_samples = None

        '''各子概念信息'''
        self.unique_combinations_ = {}
        self.reverse_combinations_ = []
        self.label_subconcepts = {}

        self.nsample_labels = []
        self.nsample_lplabel = None

        self.class_sampling = []
        self.N_resample_plus = []
        self.restresample_threshold = []
        self.resample_rest_ratio = []
        self.N_resample_rest_before = []
        self.N_resample_rest_after = []
        self.N_resampled_target_eachlabel = None
        self.N_resampled_rest_eachlabel = None

        '''存储最临近及选择权重'''
        self.T_indices = {}
        self.R_indices = {}

        '''在全数据集里的索引'''
        self.border_T = {}
        self.border_R = {}
        self.border_T_extend = {}
        self.border_R_extend = {}

        self.borderT_nndistance_self = {}
        self.borderT_nns_self = {}
        self.borderR_nndistance_self = {}
        self.borderR_nns_self = {}

        self.borderT_nndistance_inR = {}
        self.borderT_nns_inR = {}
        self.borderR_nndistance_inT = {}
        self.borderR_nns_inT = {}

        self.weight_borderT = {}
        self.weight_borderR = {}
        self.weight_densityratio_TR = {}

        '''选择参考点时用的最临近信息,仅考虑border，其余为0'''
        self.weight_seed_T_unique=None
        self.weight_seed_R_unique = None
        self.weight_T_unique = None
        self.weight_R_unique = None
        self.weight_R_unique_TRratio = None
        self.nns_resamplezone = None
        self.nns_resamplezone_T = None
        self.nns_resamplezone_all=None

        self.only1point_idx = []
        self.N_new_plus = None


    def _fit(self, X, y,ifcompare):
        self.noSampling = False
        '''计算距离矩阵（训练集样本中两两样本之间的距离）'''
        self.X_distances = pairwise_distances(X, metric='euclidean', n_jobs=self.n_jobs)

        self._N_samples, self._label_count = y.shape

        '''去噪音'''
        noise_sample_idx, noise_sample_label = self._noise_detect(y)
        noise_after_idx, noise_after_label = self._noise_detect_bydistance(
            y, noise_sample_idx, noise_sample_label)
        for i in range(len(noise_after_label)):
            y.data[noise_after_idx[i]].pop(y.rows[noise_after_idx[i]].index(noise_after_label[i]))
            y.rows[noise_after_idx[i]].remove(noise_after_label[i])

        self.noise_idx = noise_after_idx
        self.noise_label = noise_after_label

        self._N_samples, self._label_count = y.shape

        '''标签统计'''
        lp_labelvector = self.label_stastic(y)

        self.calc_IBLbl(self.nsample_labels)
        self.class_sampling = self._sampling_class_IBLbl(self.IBLbl)
        self.weight_outboard_calcu(y, compare=ifcompare)
        self.weight_innerboard_calcu(y)

        return X, y, lp_labelvector

    def fit_resample(self, X, y, resample_ratio=1,step_size=1,
                     restresample_threshold=2.0, resample_rest_ratio=1,
                     ratio_disjunction=2,label_correlation = None,ifcompare=False):


        self.W = label_correlation
        X, y, lp_labelvector = self._fit(X, y,ifcompare)
        X_resampled = X.copy()
        y_resampled = y.copy()
        self.resamplezone_calcu(lp_labelvector)
        """对少数类的外边界采样"""
        if not self.noSampling:
            self.N_sampling = resample_ratio * ((self.weight_T_unique > 0) * 1).sum()
            X_new, y_new = self.resample(X, y, self.N_sampling, step_size)
            self.N_resampled_target_eachlabel = y_new.sum(axis=0)
            X_resampled, y_resampled = safe_vstack(X_new, y_new, X_resampled, y_resampled)
            self.X_raw=X
            if X_new.shape[0]:
                self.weight_innerboard_recalcu(X_resampled, y_resampled, X_new, y_new)
        """对少数类的内边界采样"""
        if self.resample_plus and not self.noSampling:
            self.restresample_threshold.append(restresample_threshold)
            X_new_plus, y_new_plus = self.resample_rest(X, y, restresample_threshold,
                                                        resample_rest_ratio, step_size)

            self.N_new_plus = X_new_plus.shape[0]
            self.N_resampled_rest_eachlabel = np.matrix([0 for i in range(self._label_count)])

            if not X_new_plus.shape[0]:
                self.N_resample_rest_after.append(0)
            if X_new_plus.shape[0]:
                self.N_resampled_rest_eachlabel = y_new_plus.sum(axis=0)
                X_resampled, y_resampled = safe_vstack(X_new_plus, y_new_plus, X_resampled, y_resampled)
                N_resample_plus = self._N_resampleplus_calcu(restresample_threshold)
                self.N_resample_rest_after.append(N_resample_plus)

        """对少数类的内部点采样"""
        if self.resample_disjunction:
            N_samples = y_resampled.shape[0]
            X_new_disjunction, y_new_disjunction = self.resample_small_disjunction(
                X, y, N_samples, step_size, ratio_disjunction)
            if y_new_disjunction.shape[0]:
                X_resampled, y_resampled = safe_vstack(
                    X_new_disjunction, y_new_disjunction, X_resampled, y_resampled)
            self.N_disjunction_resampled_eachlabel = y_new_disjunction.sum(axis=0)
        self.nsample_labels = np.array(y_resampled.sum(axis=0))[0]
        self.calc_IBLbl(self.nsample_labels)

        print('重采样后训练集样本数：',X_resampled.shape[0])
        return X_resampled, y_resampled

    """噪音检测"""
    def _noise_detect(self, y):

        noise_sample_idx = []
        noise_sample_label = []

        nn_all = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
        nn_all.fit(self.X_distances)
        nndistance_all, nns_all = nn_all.kneighbors(n_neighbors=self.kn, return_distance=True)

        y = ensure_output_format(
            y, sparse_format='lil', require_dense=False, enforce_sparse=True)
        y_row = copy.deepcopy(y.rows)

        for i in range(self._N_samples):
            nns = nns_all[i]

            for label in y_row[i]:

                for j in range(self.kn):
                    if label in y_row[nns][j]:
                        break
                    elif j == self.kn - 1:
                        noise_sample_idx.append(i)
                        noise_sample_label.append(label)

                continue
            continue

        return np.array(noise_sample_idx), np.array(noise_sample_label)

    """根据距离进一步筛选噪音"""
    def _noise_detect_bydistance(self, y, noise_sample_idx, noise_sample_label):

        noise_after_idx = np.array([])
        for label in range(self._label_count):
            y_indicator_dense = ensure_output_format(
                y[:, label] == 1, require_dense=True, enforce_sparse=False)
            '''目标类在全数据的索引'''
            target_class_indices = np.flatnonzero(y_indicator_dense)

            '''目标类-目标类的距离矩阵'''
            X_target_distances = self.X_distances[np.ix_(
                target_class_indices, target_class_indices)]

            '''计算最临近点'''
            if len(target_class_indices) <= self.knd + 1:
                continue

            nn_target = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_target.fit(X_target_distances)
            nndistance_target, nns_target = nn_target.kneighbors(n_neighbors=self.knd, return_distance=True)

            noise_candiate_indicator = np.array(noise_sample_label) == label
            noise_candiate_bylabel = noise_sample_idx[noise_candiate_indicator]

            noise_idx_local = np.zeros(len(noise_candiate_bylabel), dtype=int)
            for i in range(len(noise_candiate_bylabel)):
                noise_idx_local[i] = np.argwhere(target_class_indices == noise_candiate_bylabel[i])

            idx_local = [i for i in range(len(target_class_indices))]
            for local_idx in noise_idx_local:
                idx_local.remove(local_idx)

            all_nns = np.unique(nns_target)

            for i in range(len(noise_idx_local)):
                if noise_idx_local[i] in all_nns:
                    idx_local.append(noise_idx_local[i])

            distance_max = np.max(nndistance_target[idx_local])

            indicator = []
            for i in range(len(noise_idx_local)):

                if nndistance_target[noise_idx_local[i]][0] > 1.5 * distance_max:
                    indicator.append(True)
                else:
                    indicator.append(False)

            noise = noise_candiate_bylabel[indicator]

            if ~noise_after_idx.any():
                noise_after_idx = noise
                noise_after_label = np.full(len(noise), label)
            else:
                noise_after_idx = np.hstack((noise_after_idx, noise))
                noise_after_label = np.hstack((noise_after_label, np.full(len(noise), label)))

        return noise_after_idx, noise_after_label

    """计算每个类的不均衡程度和平均不均衡程度"""
    def calc_IBLbl(self,nsample_labels):
        max_num=max(nsample_labels)
        self.IBLbl=[]
        for i in range(len(nsample_labels)):
            self.IBLbl.append(max_num/nsample_labels[i])
        self.IBLbl_mean=np.mean(self.IBLbl)

    """确定少数类"""
    def _sampling_class_IBLbl(self,IBLbl):
        class_sampling = []
        mean_IBLbl=np.mean(IBLbl)
        for i in range(len(IBLbl)):
            if IBLbl[i] > mean_IBLbl:
                class_sampling.append(i)

        return class_sampling

    """lp转化,将多标签转化为多类"""
    def transform_lp(self, y):
        """Transform multi-label output space to multi-class

        Transforms a mutli-label problem into a single-label multi-class
        problem where each label combination is a separate class.

        Parameters
        -----------
        y : `array_like`, :class:`numpy.matrix` or :mod:`scipy.sparse` matrix of `{0, 1}`, shape=(n_samples, n_labels)
            binary indicator matrix with label assignments

        Returns
        -------
        numpy.ndarray of `{0, ... , n_classes-1}`, shape=(n_samples,)
            a multi-class output space vector

        """

        '''

        Attributes
        ----------
        unique_combinations_ : Dict[str, int]
            mapping from label combination as string to label combination id :meth:`transform:` via :meth:`fit`
        reverse_combinations_ : List[List[int]]
            label combination id ordered list to list of label indexes for a given combination  :meth:`transform:`
            via :meth:`fit`

        '''

        y = ensure_output_format(
            y, sparse_format='lil', require_dense=False, enforce_sparse=True)

        last_id = 0
        lp_labelvector = []
        for labels_applied in y.rows:
            label_string = ",".join(map(str, labels_applied))

            if label_string not in self.unique_combinations_:
                self.unique_combinations_[label_string] = last_id
                self.reverse_combinations_.append(labels_applied)

                for label in labels_applied:
                    if label not in self.label_subconcepts:
                        self.label_subconcepts[label] = [last_id]
                    else:
                        self.label_subconcepts[label].append(last_id)

                last_id += 1

            lp_labelvector.append(self.unique_combinations_[label_string])

        return np.array(lp_labelvector)

    """返回lp转化后的多类的类向量"""
    def label_stastic(self, y):

        lp_labelvector = self.transform_lp(y)
        self.nsample_lplabel = np.unique(lp_labelvector, return_counts=True)

        self.nsample_labels = y.sum(axis=0).tolist()[0]

        return lp_labelvector

    """少数类外边界种子点选择权重计算"""
    def weight_outboard_calcu(self, y,compare=False):
        relation_dict = {}
        rest_dict = {}
        threshold = 0.6
        labels = np.array(range(self._label_count))
        for i in range(len(self.class_sampling)):
            label = self.class_sampling[i]
            rest_labels = []
            for j in range(len(labels)):
                if label == labels[j]:
                    continue
                if self.W[label][labels[j]] >= threshold and labels[j] in self.class_sampling:
                    rest_labels.append(labels[j])
                if self.W[label][labels[j]] < threshold and labels[j]  not in self.class_sampling:
                    rest_labels.append(labels[j])
            if len(rest_labels) == 0:continue
            for j in range(len(rest_labels)):
                if j == 0:
                    y_rest_index = ensure_output_format(
                        y[:, rest_labels[j]] == 1, require_dense=True, enforce_sparse=False)
                else:
                    y_rest_index = y_rest_index | ensure_output_format(
                        y[:, rest_labels[j]] == 1, require_dense=True, enforce_sparse=False)
            relation_dict[label] = y_rest_index

        if relation_dict == {}:
            self.noSampling = True
            return

        for i in range(len(self.class_sampling)):
            if i == 0:
                y_minority_index = ensure_output_format(
                    y[:, self.class_sampling[i]] == 1, require_dense=True, enforce_sparse=False)
            else:
                y_minority_index = y_minority_index | ensure_output_format(
                    y[:, self.class_sampling[i]] == 1, require_dense=True, enforce_sparse=False)
        for label in range(self._label_count):
            y_indicator_dense = ensure_output_format(
                y[:, label] == 1, require_dense=True, enforce_sparse=False)

            '''目标类在全数据的索引'''
            target_class_indices = np.flatnonzero(y_indicator_dense)
            if len(target_class_indices) == 1:
                self.T_indices[label] = copy.deepcopy(target_class_indices)
                continue
            '''rest类在全数据的索引'''
            y_rest_indicator = ~ y_indicator_dense
            if label in self.class_sampling and compare == False:
                if label not in relation_dict.keys():continue
                y_rest_indicator = y_rest_indicator & relation_dict[label]
            rest_class_indices = np.flatnonzero(y_rest_indicator)
            if len(rest_class_indices) < 6:
                continue
            '''目标类-目标类，rest类-rest类，rest类-目标类的距离矩阵'''
            X_target_distances = self.X_distances[np.ix_(
                target_class_indices, target_class_indices)]
            X_rest_distances = self.X_distances[np.ix_(
                rest_class_indices, rest_class_indices)]
            X_rest_target_distances = self.X_distances[np.ix_(
                rest_class_indices, target_class_indices)]

            '''计算最临近点'''
            k3 = min(self.k3, len(target_class_indices) - 1)
            k1 = min(self.k1, len(target_class_indices) - 1)
            nn_rest = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_rest.fit(X_rest_distances)
            nndistance_rest, nns_rest = nn_rest.kneighbors(n_neighbors=self.k4, return_distance=True)
            nndistance_target_rest, nns_target_rest = nn_rest.kneighbors(
                X_rest_target_distances.T, n_neighbors=self.k2, return_distance=True)
            border_rest = np.unique(nns_target_rest)
            nn_target = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_target.fit(X_target_distances)
            nndistance_target, nns_target = nn_target.kneighbors(n_neighbors=k3, return_distance=True)

            '''仅需考虑rest边界点的nn，来找目标类边界点'''
            nndistance_rest_target, nns_rest_target = nn_target.kneighbors(
                X_rest_target_distances[border_rest], n_neighbors=k1, return_distance=True)
            border_target = np.unique(nns_rest_target)
            '''放到类属性里'''
            self.T_indices[label] = copy.deepcopy(target_class_indices)
            self.R_indices[label] = copy.deepcopy(rest_class_indices)
            self.border_T[label] = copy.deepcopy(target_class_indices[border_target])
            self.border_R[label] = copy.deepcopy(rest_class_indices[border_rest])

            self.border_T_extend[label] = copy.deepcopy(target_class_indices[border_target])
            self.border_R_extend[label] = copy.deepcopy(rest_class_indices[border_rest])

            self.borderT_nndistance_self[label] = copy.deepcopy(nndistance_target[border_target])
            self.borderT_nns_self[label] = copy.deepcopy(target_class_indices[nns_target[border_target]])
            self.borderR_nndistance_self[label] = copy.deepcopy(nndistance_rest[border_rest])
            self.borderR_nns_self[label] = copy.deepcopy(rest_class_indices[nns_rest[border_rest]])

            self.borderT_nndistance_inR[label] = copy.deepcopy(nndistance_target_rest[border_target])
            self.borderT_nns_inR[label] = copy.deepcopy(rest_class_indices[nns_target_rest[border_target]])
            self.borderR_nndistance_inT[label] = copy.deepcopy(nndistance_rest_target)
            self.borderR_nns_inT[label] = copy.deepcopy(target_class_indices[nns_rest_target])

            '''计算目标类选择权重'''
            mean_T2T_extend = self.borderT_nndistance_self[label].mean(axis=1)
            mean_R2R_extend = self.borderR_nndistance_self[label].mean(axis=1)

            mean_T2R = self.borderT_nndistance_inR[label].mean(axis=1)
            mean_R2T = self.borderR_nndistance_inT[label].mean(axis=1)

            T2T_all0_indicator = mean_T2T_extend == 0
            T2R_all0_indicator = mean_T2R == 0
            R2T_all0_indicator = mean_R2T == 0
            T2T_0_indicator = self.borderT_nndistance_self[label][:, 0] == 0
            R2R_0_indicator = self.borderR_nndistance_self[label][:, 0] == 0

            mean_T2R[T2R_all0_indicator] = np.inf
            mean_R2T[R2T_all0_indicator] = np.inf

            '''计算rest类选择权重'''
            nn_borderR1_inT = copy.deepcopy(self.borderR_nns_inT[label][:, 0])
            nn_borderR1_inT_inborderTidx = np.zeros(len(nn_borderR1_inT), dtype=int)
            for i in range(len(nn_borderR1_inT)):
                nn_borderR1_inT_inborderTidx[i] = np.argwhere(self.border_T_extend[label] == nn_borderR1_inT[i])

            mean_T2T_extend[T2T_all0_indicator] = np.inf
            mean_R2R_extend[R2R_0_indicator] = 0
            T2T_R1nn_inT = copy.deepcopy(mean_T2T_extend[nn_borderR1_inT_inborderTidx])
            borderR_density_ratio = mean_R2R_extend[:self.border_R[label].shape[0]] / T2T_R1nn_inT
            borderR_density_ratio = borderR_density_ratio ** 2

            mean_T2T_extend[T2T_0_indicator] = 0
            weight_T = mean_T2T_extend[:self.border_T[label].shape[0]] / mean_T2R
            weight_R = mean_R2R_extend[:self.border_R[label].shape[0]] / mean_R2T

            self.weight_borderT[label] = copy.deepcopy(weight_T)

            self.weight_borderR[label] = copy.deepcopy(weight_R)
            self.weight_densityratio_TR[label] = copy.deepcopy(borderR_density_ratio)

        '''对每个一点，最大的权重保留'''
        w_T = np.zeros(self._N_samples)

        for label in self.class_sampling:
            if label not in self.border_T.keys():
                continue

            w_T[self.border_T[label]] = np.maximum(
                w_T[self.border_T[label]], self.weight_borderT[label])

        weight_T = w_T / w_T.sum()
        self.weight_T_unique = copy.deepcopy(weight_T)

    """少数类内边界种子点选择权重计算"""
    def weight_innerboard_calcu(self, y):
        for i in range(len(self.class_sampling)):
            if i == 0:
                y_minority_index = ensure_output_format(
                    y[:, self.class_sampling[i]] == 1, require_dense=True, enforce_sparse=False)
            else:
                y_minority_index = y_minority_index | ensure_output_format(
                    y[:, self.class_sampling[i]] == 1, require_dense=True, enforce_sparse=False)
        for label in range(self._label_count):
            y_indicator_dense = ensure_output_format(
                y[:, label] == 1, require_dense=True, enforce_sparse=False)
            '''目标类在全数据的索引'''
            target_class_indices = np.flatnonzero(y_indicator_dense)
            if len(target_class_indices) == 1:
                self.T_indices[label] = copy.deepcopy(target_class_indices)
                continue

            '''rest类在全数据的索引'''
            y_rest_indicator = ~ y_indicator_dense
            y_rest_indicator = y_rest_indicator & y_minority_index
            rest_class_indices = np.flatnonzero(y_rest_indicator)

            '''目标类-目标类，rest类-rest类，rest类-目标类的距离矩阵'''
            X_target_distances = self.X_distances[np.ix_(
                target_class_indices, target_class_indices)]
            X_rest_distances = self.X_distances[np.ix_(
                rest_class_indices, rest_class_indices)]
            X_rest_target_distances = self.X_distances[np.ix_(
                rest_class_indices, target_class_indices)]

            '''计算最临近点'''
            k3 = min(self.k3, len(target_class_indices) - 1)
            k1 = min(self.k1, len(target_class_indices) - 1)
            nn_rest = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_rest.fit(X_rest_distances)

            nndistance_rest, nns_rest = nn_rest.kneighbors(n_neighbors=self.k4, return_distance=True)
            nndistance_target_rest, nns_target_rest = nn_rest.kneighbors(
                X_rest_target_distances.T, n_neighbors=self.k2, return_distance=True)
            border_rest = np.unique(nns_target_rest)
            nn_target = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_target.fit(X_target_distances)
            nndistance_target, nns_target = nn_target.kneighbors(n_neighbors=k3, return_distance=True)

            '''仅需考虑rest边界点的nn，来找目标类边界点'''
            nndistance_rest_target, nns_rest_target = nn_target.kneighbors(
                X_rest_target_distances[border_rest], n_neighbors=k1, return_distance=True)
            border_target = np.unique(nns_rest_target)
            '''放到类属性里'''
            self.T_indices[label] = copy.deepcopy(target_class_indices)
            self.R_indices[label] = copy.deepcopy(rest_class_indices)

            self.border_T[label] = copy.deepcopy(target_class_indices[border_target])
            self.border_R[label] = copy.deepcopy(rest_class_indices[border_rest])

            self.border_T_extend[label] = copy.deepcopy(target_class_indices[border_target])
            self.border_R_extend[label] = copy.deepcopy(rest_class_indices[border_rest])

            self.borderT_nndistance_self[label] = copy.deepcopy(nndistance_target[border_target])
            self.borderT_nns_self[label] = copy.deepcopy(target_class_indices[nns_target[border_target]])
            self.borderR_nndistance_self[label] = copy.deepcopy(nndistance_rest[border_rest])
            self.borderR_nns_self[label] = copy.deepcopy(rest_class_indices[nns_rest[border_rest]])

            self.borderT_nndistance_inR[label] = copy.deepcopy(nndistance_target_rest[border_target])
            self.borderT_nns_inR[label] = copy.deepcopy(rest_class_indices[nns_target_rest[border_target]])
            self.borderR_nndistance_inT[label] = copy.deepcopy(nndistance_rest_target)
            self.borderR_nns_inT[label] = copy.deepcopy(target_class_indices[nns_rest_target])

            '''计算目标类选择权重'''
            mean_T2T_extend = self.borderT_nndistance_self[label].mean(axis=1)
            mean_R2R_extend = self.borderR_nndistance_self[label].mean(axis=1)

            mean_T2R = self.borderT_nndistance_inR[label].mean(axis=1)
            mean_R2T = self.borderR_nndistance_inT[label].mean(axis=1)

            T2T_all0_indicator = mean_T2T_extend == 0
            T2R_all0_indicator = mean_T2R == 0
            R2T_all0_indicator = mean_R2T == 0
            T2T_0_indicator = self.borderT_nndistance_self[label][:, 0] == 0
            R2R_0_indicator = self.borderR_nndistance_self[label][:, 0] == 0

            mean_T2R[T2R_all0_indicator] = np.inf
            mean_R2T[R2T_all0_indicator] = np.inf

            '''计算rest类选择权重'''
            nn_borderR1_inT = copy.deepcopy(self.borderR_nns_inT[label][:, 0])
            nn_borderR1_inT_inborderTidx = np.zeros(len(nn_borderR1_inT), dtype=int)
            for i in range(len(nn_borderR1_inT)):
                nn_borderR1_inT_inborderTidx[i] = np.argwhere(self.border_T_extend[label] == nn_borderR1_inT[i])

            mean_T2T_extend[T2T_all0_indicator] = np.inf
            mean_R2R_extend[R2R_0_indicator] = 0

            T2T_R1nn_inT = copy.deepcopy(mean_T2T_extend[nn_borderR1_inT_inborderTidx])

            borderR_density_ratio = mean_R2R_extend[:self.border_R[label].shape[0]] / T2T_R1nn_inT
            borderR_density_ratio = borderR_density_ratio ** 2

            mean_T2T_extend[T2T_0_indicator] = 0
            weight_T = mean_T2T_extend[:self.border_T[label].shape[0]] / mean_T2R

            weight_R = mean_R2R_extend[:self.border_R[label].shape[0]] / mean_R2T

            self.weight_borderT[label] = copy.deepcopy(weight_T)

            self.weight_borderR[label] = copy.deepcopy(weight_R)

            self.weight_densityratio_TR[label] = copy.deepcopy(borderR_density_ratio)


        w_R = np.zeros(self._N_samples)
        w_R_ratio = np.full(self._N_samples, np.inf)

        for label in range(self._label_count):

            if label not in self.border_T.keys():  # 仅有一个样本的标签
                continue

            w_R[self.border_R[label]] = np.maximum(
                w_R[self.border_R[label]], self.weight_borderR[label])
            w_R_ratio[self.border_R[label]] = np.minimum(
                w_R_ratio[self.border_R[label]], self.weight_densityratio_TR[label])

        w_R_ratio[w_R_ratio == np.inf] = 0

        weight_R = w_R / w_R.sum()
        self.weight_R_unique = copy.deepcopy(weight_R)
        self.weight_R_unique_TRratio = copy.deepcopy(w_R_ratio)

        return None

    """计算种子点到同标签集的样本群的knn"""
    def resamplezone_calcu(self, lp_labelvector):
        unique_lp = np.unique(lp_labelvector)

        self.nns_resamplezone = np.zeros([len(lp_labelvector), self.kr], dtype=int)

        self.nns_resamplezone_lesssample = {}
        self.only1point_idx=[]

        for lp_label in unique_lp:
            y_indicator_dense = ensure_output_format(
                lp_labelvector == lp_label, require_dense=True, enforce_sparse=False)

            '''目标类在全数据的索引'''
            current_lp_indices = np.flatnonzero(y_indicator_dense)
            X_currentlp_distances = self.X_distances[np.ix_(
                current_lp_indices, current_lp_indices)]

            nn_resamplezone = NearestNeighbors(
                metric='precomputed', n_jobs=self.n_jobs)
            nn_resamplezone.fit(X_currentlp_distances)

            if len(current_lp_indices) > self.kr:
                nns_resamplezone = nn_resamplezone.kneighbors(
                    n_neighbors=self.kr, return_distance=False)
                self.nns_resamplezone[current_lp_indices] = copy.deepcopy(current_lp_indices[nns_resamplezone])

            elif len(current_lp_indices) > 1:
                nns_resamplezone = nn_resamplezone.kneighbors(
                    n_neighbors=len(current_lp_indices) - 1, return_distance=False)
                for j in range(len(current_lp_indices)):
                    self.nns_resamplezone_lesssample[current_lp_indices[j]] = copy.deepcopy(
                        current_lp_indices[nns_resamplezone[j]])

            else:
                self.only1point_idx.append(current_lp_indices[0])

        nn_resamplezone_all = NearestNeighbors(
            metric='precomputed', n_jobs=self.n_jobs)
        nn_resamplezone_all.fit(self.X_distances)
        self.nns_resamplezone_all = nn_resamplezone_all.kneighbors(
            n_neighbors=self.kr, return_distance=False)

        return None

    """升采样外边界"""
    def resample(self, X, y, N_resampling, step_size):

        random_state = check_random_state(self.random_state)

        weight_selection = self.weight_T_unique
        N_resampling = int(round(N_resampling))
        sample_seed = random_state.choice(self._N_samples, size=N_resampling,
                                          replace=True, p=weight_selection)

        indicator = []
        for i in range(len(sample_seed)):
            indicator.append(sample_seed[i] not in self.only1point_idx)

        sample_seed = sample_seed[indicator]
        N_resampling = len(sample_seed)

        sample_refNeigh = random_state.randint(low=0, high=self.kr, size=N_resampling)

        for idx in list(self.nns_resamplezone_lesssample.keys()):
            seed_idx = np.argwhere(sample_seed == idx)
            sample_refNeigh[seed_idx] = random_state.randint(
                low=0, high=len(self.nns_resamplezone_lesssample[idx]), size=1)

        steps = step_size * random_state.uniform(size=N_resampling)
        y_new = copy.deepcopy(y[sample_seed])

        if sparse.issparse(X):
            row_indices, col_indices, samples = [], [], []
            for i, (row, col, step) in enumerate(zip(sample_seed, sample_refNeigh, steps)):
                if X[row].nnz:
                    sample = self._generate_sample(X, row, col, step)

                    row_indices += [i] * len(sample.indices)
                    col_indices += sample.indices.tolist()
                    samples += sample.data.tolist()

            return (sparse.csr_matrix((samples, (row_indices, col_indices)),
                                      [N_resampling, X.shape[1]],
                                      dtype=X.dtype),
                    y_new)
        else:
            X_new = np.zeros((N_resampling, X.shape[1]), dtype=X.dtype)
            for i, (row, col, step) in enumerate(zip(sample_seed, sample_refNeigh, steps)):
                X_new[i] = self._generate_sample(X, row, col, step)

            return X_new, y_new

    """合成新样本"""
    def _generate_sample(self, X, seed, refNeigh, step):
        if seed in self.nns_resamplezone_lesssample.keys():
            diff_X = X[seed] - X[self.nns_resamplezone_lesssample[seed][refNeigh]]

            return X[seed] - step * diff_X
        elif seed in self.only1point_idx:
            diff_X = X[seed] - X[self.nns_resamplezone_all[seed][refNeigh]]

            return X[seed] - step * diff_X
        else:
            diff_X = X[seed] - X[self.nns_resamplezone[seed, refNeigh]]

            return X[seed] - step * diff_X

    """升采样内边界"""
    def resample_rest(self, X, y, threshold, resample_rest_ratio, step_size):

        candidate_idx = np.where(self.weight_R_unique_TRratio > threshold)[0]

        if len(candidate_idx) == 0:
            self.N_resample_plus.append(0)

            return np.array([]), np.array([])

        candidate = self.weight_R_unique_TRratio[candidate_idx]

        N_resample_weight = candidate / threshold - 1
        N_resample_ = np.minimum(np.floor(N_resample_weight), 5)
        self.N_resample_plus.append(int(N_resample_.sum()))
        sample_seed = candidate_idx[np.nonzero(N_resample_)]
        N_resample_ -= 1
        N_resample_ = np.maximum(N_resample_, 0)
        while N_resample_.any():
            sample_seed = np.append(sample_seed, candidate_idx[np.nonzero(N_resample_)])
            N_resample_ -= 1
            N_resample_ = np.maximum(N_resample_, 0)

        random_state = check_random_state(self.random_state)

        indicator = []
        for i in range(len(sample_seed)):
            indicator.append(sample_seed[i] not in self.only1point_idx)

        sample_seed = sample_seed[indicator]
        N_resample = len(sample_seed)

        sample_refNeigh = random_state.randint(low=0, high=self.kr, size=N_resample)

        for idx in list(self.nns_resamplezone_lesssample.keys()):
            seed_idx = np.argwhere(sample_seed == idx)
            sample_refNeigh[seed_idx] = random_state.randint(
                low=0, high=len(self.nns_resamplezone_lesssample[idx]), size=1)

        steps = step_size * random_state.uniform(size=N_resample)

        y_new = copy.deepcopy(y[sample_seed])

        if sparse.issparse(X):
            row_indices, col_indices, samples = [], [], []
            for i, (row, col, step) in enumerate(zip(sample_seed, sample_refNeigh, steps)):
                if X[row].nnz:
                    sample = self._generate_sample(X, row, col, step)
                    row_indices += [i] * len(sample.indices)
                    col_indices += sample.indices.tolist()
                    samples += sample.data.tolist()
            return (sparse.csr_matrix((samples, (row_indices, col_indices)),
                                      [N_resample, X.shape[1]],
                                      dtype=X.dtype),
                    y_new)
        else:
            X_new = np.zeros((N_resample, X.shape[1]), dtype=X.dtype)
            for i, (row, col, step) in enumerate(zip(sample_seed, sample_refNeigh, steps)):
                X_new[i] = self._generate_sample(X, row, col, step)

            return X_new, y_new


    def _N_resampleplus_calcu(self, threshold):

        candidate_idx = np.where(self.weight_R_unique_TRratio > threshold)[0]

        if len(candidate_idx) == 0:
            return 0

        candidate = self.weight_R_unique_TRratio[candidate_idx]
        N_resample_weight = candidate / threshold - 1
        N_resample_ = np.minimum(np.floor(N_resample_weight), 5)
        N_resample = int(N_resample_.sum())
        return N_resample

    """升采样内部点"""
    def resample_small_disjunction(self, X, y, N_samples, step_size, ratio_mean):

        if not self.noSampling:
            inner_samples = np.intersect1d(np.flatnonzero(self.weight_R_unique == 0),
                                           np.flatnonzero(self.weight_T_unique == 0))
        else:
            inner_samples = np.array(range(self._N_samples))
        num_sample_eachlabel = []
        for i in range(self._label_count):
            y_indicator_dense = ensure_output_format(
                y[:, i] == 1, require_dense=True, enforce_sparse=False)
            '''目标类在全数据的索引'''
            target_indices = np.flatnonzero(y_indicator_dense)
            self.T_indices[i] = target_indices
        for i in range(self._label_count):
            num_sample_eachlabel.append(len(self.T_indices[i]))
        num_sample_eachlabel = np.array(num_sample_eachlabel)

        IRLbl = N_samples / num_sample_eachlabel
        meanIR = IRLbl.mean()

        class_resample = np.flatnonzero(IRLbl > meanIR * ratio_mean)

        class_median = np.setdiff1d(IRLbl, IRLbl[class_resample]).max()
        class_median = np.flatnonzero(IRLbl == class_median)
        N_resample_eachlabel = num_sample_eachlabel[class_median][0] - num_sample_eachlabel[class_resample]
        N_resample_eachlabel = pd.Series(data=N_resample_eachlabel, index=class_resample)

        self.N_disjunction_resample_eachlabel = copy.deepcopy(N_resample_eachlabel)

        for i in range(len(class_resample)):
            N_resampling = N_resample_eachlabel[N_resample_eachlabel > 0].sort_values()[0:1]
            if N_resampling.any():

                class_resampling = N_resampling.index[0]
                N_resampling = N_resampling.values

                samples_seed = np.intersect1d(self.T_indices[class_resampling], inner_samples)

                if ~samples_seed.any():
                    samples_seed = self.T_indices[class_resampling][self.T_indices[class_resampling] < self._N_samples]
                X_new, y_new = self._resample_by_seeds(X, y, samples_seed, N_resampling, step_size)

                num_resampled_eachlabel = np.array(y_new.sum(axis=0))[0]

                N_resample_eachlabel = N_resample_eachlabel - num_resampled_eachlabel[N_resample_eachlabel.index.values]

                class_resample_diff = np.setdiff1d(N_resample_eachlabel.index.values, class_resampling)
                N_resample_eachlabel = N_resample_eachlabel[class_resample_diff]

                if i == 0:
                    X_new_all, y_new_all = X_new, y_new
                else:
                    X_new_all, y_new_all = safe_vstack(X_new, y_new, X_new_all, y_new_all)

        if ~class_resample.any():
            return np.array([]), np.array([])
        else:

            return X_new_all, y_new_all


    def _resample_by_seeds(self, X, y, samples_seed, N_resampling, step_size):

        random_state = check_random_state(self.random_state)

        sample_seed = random_state.choice(samples_seed, size=N_resampling,
                                          replace=True, p=None)

        indicator = []
        for i in range(len(sample_seed)):
            indicator.append(sample_seed[i] not in self.only1point_idx)

        sample_seed = sample_seed[indicator]
        N_resampling = len(sample_seed)

        sample_refNeigh = random_state.randint(low=0, high=self.kr, size=N_resampling)

        for idx in list(self.nns_resamplezone_lesssample.keys()):
            seed_idx = np.argwhere(sample_seed == idx)
            sample_refNeigh[seed_idx] = random_state.randint(
                low=0, high=len(self.nns_resamplezone_lesssample[idx]), size=1)

        steps = step_size * random_state.uniform(size=N_resampling)

        y_new = copy.deepcopy(y[sample_seed])

        if sparse.issparse(X):
            row_indices, col_indices, samples = [], [], []
            for i, (row, col, step) in enumerate(zip(sample_seed, sample_refNeigh, steps)):
                if X[row].nnz:
                    sample = self._generate_sample(X, row, col, step)
                    row_indices += [i] * len(sample.indices)
                    col_indices += sample.indices.tolist()
                    samples += sample.data.tolist()
            return (sparse.csr_matrix((samples, (row_indices, col_indices)),
                                      [N_resampling, X.shape[1]],
                                      dtype=X.dtype),
                    y_new)
        else:
            X_new = np.zeros((N_resampling, X.shape[1]), dtype=X.dtype)
            for i, (row, col, step) in enumerate(zip(sample_seed, sample_refNeigh, steps)):
                X_new[i] = self._generate_sample(X, row, col, step)

            return X_new, y_new

    """重新计算少数类内边界种子点选择权重"""
    def weight_innerboard_recalcu(self, X_resampled, y_resampled, X_new, y_new):
        for i in range(len(self.class_sampling)):
            if i == 0:
                y_minority_index2 = ensure_output_format(
                    y_new[:, self.class_sampling[i]] == 1, require_dense=True, enforce_sparse=False)
            else:
                y_minority_index2 = y_minority_index2 | ensure_output_format(
                    y_new[:, self.class_sampling[i]] == 1, require_dense=True, enforce_sparse=False)

        Xnew_X_distances = pairwise_distances(X=X_new,
                                              Y=X_resampled, metric='euclidean', n_jobs=self.n_jobs)
        new_begin_idx = y_resampled.shape[0] - y_new.shape[0]

        for label in range(self._label_count):

            if label not in self.border_T.keys():
                continue

            '''目标类的新样本在new数据里的索引[True,False,...]'''
            ynew_target_indicator = ensure_output_format(
                y_new[:, label] == 1, require_dense=True, enforce_sparse=False)
            '''目标类的新样本在new数据里的索引'''
            new_target_indices = np.flatnonzero(ynew_target_indicator)
            '''目标类的新样本在resampled数据里的索引'''
            new_target_idx_inresampled = new_target_indices + new_begin_idx
            '''rest类的新样本在new数据的索引'''
            ynew_rest_indicator = ~ ynew_target_indicator
            ynew_rest_indicator = ynew_rest_indicator & y_minority_index2
            new_rest_indices = np.flatnonzero(ynew_rest_indicator)
            '''rest类的新样本在resampled数据里的索引'''
            new_rest_idx_inresampled = new_rest_indices + new_begin_idx

            new_k3k1_calcu = len(self.T_indices[label]) + len(new_target_idx_inresampled) - 1
            k3 = min(self.k3, new_k3k1_calcu)
            k1 = min(self.k1, new_k3k1_calcu)

            '''加入了new样本的新的距离矩阵，在原border的KNN距离基础上'''

            '''new_T - 所有T, new_R - 所有R, new_R - borderT, new_T - borderR 的距离矩阵'''
            newT_T_distances = Xnew_X_distances[np.ix_(
                new_target_indices, np.append(self.T_indices[label], new_target_idx_inresampled))]

            newR_R_distances = Xnew_X_distances[np.ix_(
                new_rest_indices, np.append(self.R_indices[label], new_rest_idx_inresampled))]

            newR_borderT_distances = Xnew_X_distances[np.ix_(new_rest_indices, self.border_T[label])]

            newT_borderR_distances = Xnew_X_distances[np.ix_(new_target_indices, self.border_R[label])]

            '''borderT'''
            num_newT, num_T = newT_T_distances.shape
            '''newT 在T内的KNN'''
            if num_newT != 0:
                nn_newT = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
                nn_newT.fit(np.zeros([num_T, num_T]))

                nndistance_newT_, nns_newT = nn_newT.kneighbors(newT_T_distances, n_neighbors=k3 + 1,
                                                                return_distance=True)

                nndistance_newT_ = nndistance_newT_[:, 1:]
                nns_newT = nns_newT[:, 1:]

                idx_T_resampled = np.append(self.T_indices[label], new_target_idx_inresampled)

                nns_newT = copy.deepcopy(idx_T_resampled[nns_newT])

                '''borderT extend - k3nn、newT 距离  '''
                borderT_extend_inTidx = np.zeros(len(self.border_T_extend[label]), dtype=int)
                for i in range(len(borderT_extend_inTidx)):
                    borderT_extend_inTidx[i] = np.argwhere(self.T_indices[label] == self.border_T_extend[label][i])

                nndistance_borderT_extend = np.hstack(
                    (self.borderT_nndistance_self[label], newT_T_distances.T[borderT_extend_inTidx]))

                '''borderT 在T内的KNN'''

                nn_borderT = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
                nn_borderT.fit(np.zeros([min(k3 + num_newT, new_k3k1_calcu), min(k3 + num_newT, new_k3k1_calcu)]))

                nn_distance_borderT, nns_borderT = nn_borderT.kneighbors(nndistance_borderT_extend, n_neighbors=k3,
                                                                         return_distance=True)

                if self.borderT_nns_self[label].shape[1] < self.k3:
                    borderT_nns_self = np.zeros([self.borderT_nns_self[label].shape[0], k3], dtype=int)
                    for i in range(nns_borderT.shape[0]):
                        idx_mapping = np.hstack((self.borderT_nns_self[label][i], new_target_idx_inresampled))
                        borderT_nns_self[i] = copy.deepcopy(idx_mapping[nns_borderT[i]])
                    self.borderT_nns_self[label] = copy.deepcopy(borderT_nns_self)
                else:
                    for i in range(nns_borderT.shape[0]):
                        idx_mapping = np.hstack((self.borderT_nns_self[label][i], new_target_idx_inresampled))
                        self.borderT_nns_self[label][i] = copy.deepcopy(idx_mapping[nns_borderT[i]])

                '''borderT + newT 在T内的KNN，全局索引'''
                self.borderT_nns_self[label] = np.vstack((self.borderT_nns_self[label], nns_newT))
                self.borderT_nndistance_self[label] = np.vstack((nn_distance_borderT, nndistance_newT_))

                '''borderT + newT 在全局的索引'''
                self.border_T_extend[label] = np.hstack((self.border_T_extend[label], new_target_idx_inresampled))

            ''' borderR'''
            num_newR, num_R = newR_R_distances.shape
            '''newR 在R内的KNN'''
            if num_newR != 0:
                nn_newR = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
                nn_newR.fit(np.zeros([num_R, num_R]))

                nndistance_newR_, nns_newR = nn_newR.kneighbors(newR_R_distances, n_neighbors=self.k4 + 1,
                                                                return_distance=True)

                nndistance_newR_ = nndistance_newR_[:, 1:]
                nns_newR = nns_newR[:, 1:]

                idx_R_resampled = np.append(self.R_indices[label], new_rest_idx_inresampled)
                nns_newR = copy.deepcopy(idx_R_resampled[nns_newR])

                '''borderR - k4nn、newR 距离  '''
                borderR_extend_inRidx = np.zeros(len(self.border_R_extend[label]), dtype=int)
                for i in range(len(borderR_extend_inRidx)):
                    borderR_extend_inRidx[i] = np.argwhere(self.R_indices[label] == self.border_R_extend[label][i])

                nndistance_borderR_extend = np.hstack(
                    (self.borderR_nndistance_self[label], newR_R_distances.T[borderR_extend_inRidx]))
                '''borderR 在R内的KNN'''
                nn_borderR = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
                nn_borderR.fit(np.zeros([self.k4 + num_newR, self.k4 + num_newR]))

                nn_distance_borderR, nns_borderR = nn_borderR.kneighbors(nndistance_borderR_extend, n_neighbors=self.k4,
                                                                         return_distance=True)

                for i in range(nns_borderR.shape[0]):
                    idx_mapping = np.append(self.borderR_nns_self[label][i], new_rest_idx_inresampled)
                    self.borderR_nns_self[label][i] = copy.deepcopy(idx_mapping[nns_borderR[i]])

                '''borderR + newR 在R内的KNN，全局索引'''
                self.borderR_nns_self[label] = np.vstack((self.borderR_nns_self[label], nns_newR))
                self.borderR_nndistance_self[label] = np.vstack((nn_distance_borderR, nndistance_newR_))
                '''borderR + newR 在全局的索引'''
                self.border_R_extend[label] = np.hstack((self.border_R_extend[label], new_rest_idx_inresampled))

            '''更新T和R的目录'''
            self.T_indices[label] = np.hstack((self.T_indices[label], new_target_idx_inresampled))
            self.R_indices[label] = np.hstack((self.R_indices[label], new_rest_idx_inresampled))

            '''找距离T最近的R'''
            borderT_nndistance_inR_extend = np.hstack((self.borderT_nndistance_inR[label], newR_borderT_distances.T))

            nn_newR_T = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_newR_T.fit(np.zeros([self.k2 + num_newR, self.k2 + num_newR]))
            nn_distance_borderT_inR, nns_borderT_inR = nn_newR_T.kneighbors(borderT_nndistance_inR_extend,
                                                                            n_neighbors=self.k2, return_distance=True)

            for i in range(nns_borderT_inR.shape[0]):
                idx_mapping = np.append(self.borderT_nns_inR[label][i], new_rest_idx_inresampled)
                self.borderT_nns_inR[label][i] = copy.deepcopy(idx_mapping[nns_borderT_inR[i]])
            self.borderT_nndistance_inR[label] = copy.deepcopy(nn_distance_borderT_inR)

            '''找距离R最近的T'''
            borderR_nndistance_inT_extend = np.hstack((self.borderR_nndistance_inT[label], newT_borderR_distances.T))
            nn_newT_R = NearestNeighbors(metric='precomputed', n_jobs=self.n_jobs)
            nn_newT_R.fit(np.zeros([min(k1 + num_newT, len(self.T_indices[label]) - 1),
                                    min(k1 + num_newT, len(self.T_indices[label]) - 1)]))
            nn_distance_borderR_inT, nns_borderR_inT = nn_newT_R.kneighbors(borderR_nndistance_inT_extend,
                                                                            n_neighbors=k1, return_distance=True)

            if self.borderR_nns_inT[label].shape[1] < self.k1:
                borderR_nns_inT = np.zeros([self.borderR_nns_inT[label].shape[0], k1], dtype=int)
                for i in range(nns_borderR_inT.shape[0]):
                    idx_mapping = np.append(self.borderR_nns_inT[label][i], new_target_idx_inresampled)
                    borderR_nns_inT[i] = copy.deepcopy(idx_mapping[nns_borderR_inT[i]])
                self.borderR_nns_inT[label] = copy.deepcopy(borderR_nns_inT)
            else:
                for i in range(nns_borderR_inT.shape[0]):
                    idx_mapping = np.append(self.borderR_nns_inT[label][i], new_target_idx_inresampled)
                    self.borderR_nns_inT[label][i] = copy.deepcopy(
                        idx_mapping[nns_borderR_inT[i]])

            self.borderR_nndistance_inT[label] = copy.deepcopy(nn_distance_borderR_inT)

            '''计算目标类选择权重'''
            mean_T2T_extend = self.borderT_nndistance_self[label].mean(axis=1)
            mean_R2R_extend = self.borderR_nndistance_self[label].mean(axis=1)

            mean_T2R = self.borderT_nndistance_inR[label].mean(axis=1)
            mean_R2T = self.borderR_nndistance_inT[label].mean(axis=1)

            T2T_all0_indicator = mean_T2T_extend == 0
            T2R_all0_indicator = mean_T2R == 0

            R2T_all0_indicator = mean_R2T == 0

            T2T_0_indicator = self.borderT_nndistance_self[label][:, 0] == 0
            R2R_0_indicator = self.borderR_nndistance_self[label][:, 0] == 0

            mean_T2R[T2R_all0_indicator] = np.inf
            mean_R2T[R2T_all0_indicator] = np.inf

            '''计算rest类选择权重'''

            nn_borderR1_inT = copy.deepcopy(self.borderR_nns_inT[label][:, 0])
            nn_borderR1_inT_inborderTidx = np.zeros(len(nn_borderR1_inT), dtype=int)

            for i in range(len(nn_borderR1_inT)):
                nn_borderR1_inT_inborderTidx[i] = np.argwhere(self.border_T_extend[label] == nn_borderR1_inT[i])

            mean_T2T_extend[T2T_all0_indicator] = np.inf

            mean_R2R_extend[R2R_0_indicator] = 0

            meandistance_R1nn_inT = copy.deepcopy(mean_T2T_extend[nn_borderR1_inT_inborderTidx])
            borderR_density_ratio = mean_R2R_extend[:self.border_R[label].shape[0]] / meandistance_R1nn_inT

            borderR_density_ratio = borderR_density_ratio ** 2

            mean_T2T_extend[T2T_0_indicator] = 0

            weight_T = mean_T2T_extend[:self.border_T[label].shape[0]] / mean_T2R

            weight_R = mean_R2R_extend[:self.border_R[label].shape[0]] / mean_R2T

            self.weight_borderT[label] = copy.deepcopy(weight_T)

            self.weight_borderR[label] = copy.deepcopy(weight_R)
            self.weight_densityratio_TR[label] = copy.deepcopy(borderR_density_ratio)

        '''对每个一点，最大的权重保留'''
        w_T = np.zeros(self._N_samples)

        for label in self.class_sampling:
            if label not in self.border_T.keys():
                continue

            w_T[self.border_T[label]] = np.maximum(
                w_T[self.border_T[label]], self.weight_borderT[label])

        weight_T = w_T / w_T.sum()
        self.weight_T_unique = copy.deepcopy(weight_T)

        w_R = np.zeros(self._N_samples)
        w_R_ratio = np.full(self._N_samples, np.inf)

        for label in range(self._label_count):

            if label not in self.border_T.keys():
                continue

            w_R[self.border_R[label]] = np.maximum(
                w_R[self.border_R[label]], self.weight_borderR[label])
            w_R_ratio[self.border_R[label]] = np.minimum(
                w_R_ratio[self.border_R[label]], self.weight_densityratio_TR[label])

        w_R_ratio[w_R_ratio == np.inf] = 0

        weight_R = w_R / w_R.sum()
        self.weight_R_unique = copy.deepcopy(weight_R)
        self.weight_R_unique_TRratio = copy.deepcopy(w_R_ratio)

        return None