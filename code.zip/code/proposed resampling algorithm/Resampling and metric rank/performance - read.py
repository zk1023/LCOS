# -*- coding: utf-8 -*-
import os
import pandas as pd
import openpyxl

datasheet_all = ['enron','medical','yeast','scene','birds','flags','Corel5k','bibtex',
                'rcv1subset1','rcv1subset2','yahoo-Arts','yahoo-Education']

resample_r = [3]
clf_name_all = ["BR","CC", "MLKNN", "CLR", "HOMER","ECC"]
metric_all = ["f1 macro","ave auc macro"]

dir_performance_input_upper = 'metric value folds/regroup metric value/'
saved_dir_performance_input_upper = 'metric value folds/saved metric value/'

dir_performance_show = '../method rank/'


if not os.path.exists(dir_performance_show):
    os.makedirs(dir_performance_show)

table_dict = {}
saved_table_dict = {}
for resample_ra in resample_r:
    print(resample_ra)
    for datasheet in datasheet_all:
        print(datasheet)
        for clf_name in clf_name_all:

            table_name = str(resample_ra) + datasheet + clf_name

            dir_performance_input = dir_performance_input_upper + datasheet + clf_name + '.csv'
            if os.path.exists(dir_performance_input):
                table_dict[table_name] = pd.read_csv(dir_performance_input, index_col=0)

            dir_performance_input = saved_dir_performance_input_upper + datasheet + clf_name + '.csv'
            if os.path.exists(dir_performance_input):
                saved_table_dict[table_name] = pd.read_csv(dir_performance_input, index_col=0)

"""每一个采样方法下的不同分类器在不同数据集中的不同评价指标的结果（结果为指标的具体值）"""
def write_performance_toexcel(sheet, metric_name):
    for data_count in range(len(datasheet_all)):
        datasheet = datasheet_all[data_count]
        sheet.cell(data_count + 3, 1, datasheet)

        for clf_count in range(len(clf_name_all)):
            clf_name = clf_name_all[clf_count]
            table_name = str(resample_ra) + datasheet + clf_name
            if data_count == 0:
                sheet.cell(1, 1).value = metric_name
                sheet.merge_cells(start_row=1, start_column=1, end_row=2, end_column=1)
                sheet.cell(1, clf_count * 4 + 2).value = clf_name
                sheet.merge_cells(start_row=1, start_column=clf_count * 4 + 2, end_row=1, end_column=clf_count * 4 + 5)
                sheet.cell(2, clf_count * 4 + 2).value = "mlsmote"
                sheet.cell(2, clf_count * 4 + 3).value = "mlsosl"
                sheet.cell(2, clf_count * 4 + 4).value = "our"
                sheet.cell(2, clf_count * 4 + 5).value = "original"
            if table_name in table_dict.keys():
                sheet.cell(data_count + 3, clf_count * 4 + 2).value = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsmote']
                sheet.cell(data_count + 3, clf_count * 4 + 3).value = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsosl']
                sheet.cell(data_count + 3, clf_count * 4 + 4).value = table_dict[table_name][metric_name]['trainRePlus2.5dj']
                sheet.cell(data_count + 3, clf_count * 4 + 5).value = saved_table_dict[table_name][metric_name]['train']

resample_ra = 3
wb = openpyxl.Workbook()
for metric_name in metric_all:
    sheet = wb.create_sheet(metric_name)
    write_performance_toexcel(sheet, metric_name)
wb.save(os.path.join(dir_performance_show, "performance2.xlsx"))

"""每一个评价指标的不同采样方法的平均排名"""
def compare_paper_ranking_metric(sheet):
    for metric_count in range(len(metric_all)):

        rank_all = pd.DataFrame()
        metric_name = metric_all[metric_count]
        sheet.cell(metric_count + 2, 1).value = metric_name
        if metric_count == 0:
            sheet.cell(1, 2).value = "original"
            sheet.cell(1, 3).value = "mlsosl"
            sheet.cell(1, 4).value = "our"
            sheet.cell(1, 5).value = "mlsmote"

        for data_count in range(len(datasheet_all)):
            datasheet = datasheet_all[data_count]
            for clf_count in range(len(clf_name_all)):
                clf_name = clf_name_all[clf_count]
                table_name = str(resample_ra) + datasheet + clf_name
                if table_name in table_dict.keys():
                    value_original = saved_table_dict[table_name][metric_name]['train']
                    value_mlsosl = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsosl']
                    value_our = table_dict[table_name][metric_name]['trainRePlus2.5dj']
                    value_mlsmote = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsmote']

                    if metric_name in ["hamming loss", "ranking loss"]:
                        rank_current = pd.DataFrame(
                            [value_original, value_mlsosl, value_our, value_mlsmote]).rank(ascending=True, method='min')
                    else:
                        rank_current = pd.DataFrame(
                            [value_original, value_mlsosl, value_our, value_mlsmote]).rank(ascending=False, method='min')
                    rank_all = rank_all.append(rank_current.T)
        rank_mean = rank_all.mean(axis=0)
        sheet.cell(metric_count + 2, 2).value = rank_mean[0]
        sheet.cell(metric_count + 2, 3).value = rank_mean[1]
        sheet.cell(metric_count + 2, 4).value = rank_mean[2]
        sheet.cell(metric_count + 2, 5).value = rank_mean[3]


resample_ra = 3
wb = openpyxl.Workbook()
sheet = wb.worksheets[0]
compare_paper_ranking_metric(sheet)
wb.save(os.path.join(dir_performance_show, "regroup_compare_paper_ranking_metric.xlsx"))

"""每一个分类器的不同采样方法的平均排名"""
def compare_paper_ranking_clf(sheet):
    for clf_count in range(len(clf_name_all)):
        clf_name = clf_name_all[clf_count]
        rank_all = pd.DataFrame()
        sheet.cell(clf_count + 2, 1).value = clf_name

        if clf_count == 0:
            sheet.cell(1, 2).value = "original"
            sheet.cell(1, 3).value = "mlsosl"
            sheet.cell(1, 4).value = "our"
            sheet.cell(1, 5).value = "mlsmote"

        for data_count in range(len(datasheet_all)):
            datasheet = datasheet_all[data_count]
            for metric_count in range(len(metric_all)):
                metric_name = metric_all[metric_count]
                table_name = str(resample_ra) + datasheet + clf_name

                if table_name in table_dict.keys():
                    value_original = saved_table_dict[table_name][metric_name]['train']
                    value_mlsosl = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsosl']
                    value_our = table_dict[table_name][metric_name]['trainRePlus2.5dj']
                    value_mlsmote = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsmote']

                    if metric_name in ["hamming loss", "ranking loss"]:
                        rank_current = pd.DataFrame(
                            [value_original, value_mlsosl, value_our, value_mlsmote]).rank(ascending=True, method='min')
                    else:
                        rank_current = pd.DataFrame(
                            [value_original, value_mlsosl, value_our, value_mlsmote]).rank(ascending=False, method='min')
                    rank_all = rank_all.append(rank_current.T)
        rank_mean = rank_all.mean(axis=0)
        sheet.cell(clf_count + 2, 2).value = rank_mean[0]
        sheet.cell(clf_count + 2, 3).value = rank_mean[1]
        sheet.cell(clf_count + 2, 4).value = rank_mean[2]
        sheet.cell(clf_count + 2, 5).value = rank_mean[3]


resample_ra = 3
wb = openpyxl.Workbook()
sheet = wb.worksheets[0]
compare_paper_ranking_clf(sheet)
wb.save(os.path.join(dir_performance_show, "regroup_compare_paper_ranking_clf.xlsx"))

"""每一个数据集的不同采样方法的平均排名"""
def compare_paper_ranking_datasheet(sheet):
    for data_count in range(len(datasheet_all)):
        datasheet = datasheet_all[data_count]
        rank_all = pd.DataFrame()
        sheet.cell(data_count + 2, 1).value = datasheet

        if data_count == 0:
            sheet.cell(1, 2).value = "original"
            sheet.cell(1, 3).value = "mlsosl"
            sheet.cell(1, 4).value = "our"
            sheet.cell(1, 5).value = "mlsmote"


        for clf_count in range(len(clf_name_all)):
            clf_name = clf_name_all[clf_count]

            for metric_count in range(len(metric_all)):
                metric_name = metric_all[metric_count]
                table_name = str(resample_ra) + datasheet + clf_name

                if table_name in table_dict.keys():
                    value_original = saved_table_dict[table_name][metric_name]['train']
                    value_mlsosl = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsosl']
                    value_our = table_dict[table_name][metric_name]['trainRePlus2.5dj']
                    value_mlsmote = saved_table_dict[table_name][metric_name]['trainRePlus2.5dj_mlsmote']

                    if metric_name in ["hamming loss", "ranking loss"]:
                        rank_current = pd.DataFrame(
                            [value_original, value_mlsosl, value_our, value_mlsmote]).rank(ascending=True, method='min')
                    else:
                        rank_current = pd.DataFrame(
                            [value_original, value_mlsosl, value_our, value_mlsmote]).rank(ascending=False, method='min')
                    rank_all = rank_all.append(rank_current.T)
        rank_mean = rank_all.mean(axis=0)
        sheet.cell(data_count + 2, 2).value = rank_mean[0]
        sheet.cell(data_count + 2, 3).value = rank_mean[1]
        sheet.cell(data_count + 2, 4).value = rank_mean[2]
        sheet.cell(data_count + 2, 5).value = rank_mean[3]

resample_ra = 3
wb = openpyxl.Workbook()
sheet = wb.worksheets[0]
compare_paper_ranking_datasheet(sheet)
wb.save(os.path.join(dir_performance_show, "regroup_compare_paper_ranking_datasheet.xlsx"))