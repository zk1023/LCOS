import pandas as pd
import os.path

def process():
    path2 = r"../result_write_all/regroup result/result_write.txt"
    clf_name_all = ["BR", "CC", "MLKNN", "CLR", "HOMER","ECC"]
    target_path = "../metric value folds/regroup metric value/"

    if not os.path.exists(target_path):
        os.makedirs(target_path)

    with open(path2, "r") as f:
        lines = f.readlines()
        count = 1
        clf_count = 0
        name = ""
        for line in lines:
            print(line)
            if count == 1:
                temp = []
                name = line.split(":")[-1].strip()
                count += 1
                continue
            if count == 2:
                count += 1
                continue
            ss = line.split("\t")
            temp.append([ss[1], ss[2]])

            if count % 2 == 0:
                res = pd.DataFrame(temp)
                res.columns = ["f1 macro", "ave auc macro"]
                res.index = ['trainRePlus2.5dj','trainRePlus2.5dj_compare']
                res.to_csv(target_path + name + clf_name_all[clf_count]+ ".csv")
                clf_count += 1
                temp = []
            count += 1
            if count == 15:
                count = 1
                clf_count = 0


if __name__ == "__main__":
    process()



