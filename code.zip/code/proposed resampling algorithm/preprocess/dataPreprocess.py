# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from skmultilearn.dataset import load_dataset, save_to_arff, load_from_arff
from sklearn.preprocessing import StandardScaler
from ormlsmote_class import Ormlsmote
from sklearn.model_selection import KFold
import os
from scipy import sparse
from ormlsmote_utils import ensure_output_format, safe_vstack
import copy
from mlsmote_class import MultiLabelSmote
from mlsmote_class_change import MultiLabelSmote_change
from label_correlation import emotion_correlation,scene_correlation,yeast_correlation,birds_correlation,enron_correlation,medical_correlation


def labelRemove_largedataset(y):
    #数据集标签个数大于50的 筛选至50
    #按照标签含样本数进行降序排序  取前50名的标签
    y = y.todense()
    if y.shape[1] <= 50 : return sparse.lil_matrix(y)
    label_count_large = y.sum(axis=0).tolist()[0] #转化为列表
    new_y_idx = sorted(range(len(label_count_large)),key= lambda i: label_count_large[i],reverse=True)[:50]
    return sparse.lil_matrix(y[:,new_y_idx])

def featureSelection(X):
    #数据集特征个数大于10000的  筛选前1%
    #数据集特征个数小于10000大于1000的  筛选前10%
    #按照特征在样本中出现的次数(特征值非0表示出现)进行降序排序 取前1%或者10%的特征
    X = X.todense()
    if X.shape[1] <= 1000: return sparse.lil_matrix(X)
    m,n = X.shape[0],X.shape[1]
    feature_count = []
    for j in range(n):
        count = 0
        for i in range(m):
            if int(X[i,j]) != 0: count += 1
        feature_count.append(count)
    new_X_idx = sorted(range(len(feature_count)), key=lambda k: feature_count[k], reverse=True)
    if n > 10000: new_X_idx = new_X_idx[:int(0.01 * n)]
    else: new_X_idx = new_X_idx[:int(0.1 * n)]
    return sparse.lil_matrix(X[:, new_X_idx])

"""直接将训练集、测试集中的异常标签(含有样本数小于10)删除掉，删除的是标签"""
def preprocess(X, y):
    """
    去除掉标签对应的样本个数少于10的样本
    去除掉样本的标签全是0的样本
    :return:
    """
    X = X.todense()
    y = y.todense()
    y_raw = copy.deepcopy(y)
    # 去除掉标签对应的样本个数少于10的样本
    label_count = y.sum(axis=0)
    move_idx = np.flatnonzero(label_count <20)
    y = np.delete(y, move_idx, axis=1)
    # 去除掉样本标签全为0的样本
    del_idx = np.flatnonzero(y.sum(axis=1) == 0)
    X = np.delete(X, del_idx, axis=0)
    X = sparse.lil_matrix(X)
    y = np.delete(y, del_idx, axis=0)
    y = sparse.lil_matrix(y)
    # 统计含有不同数量标签的样本数（只含有一个标签的有多少个，只含有两个标签的有多少个...）
    label_num1 = pd.DataFrame(y.sum(axis=1))
    res1 = list(label_num1.iloc[:, 0:].value_counts().values)
    # 统计每个类别对应多少样本(包含类1的有多少个样本，包含类2的有多少个样本...)
    label_num2 = pd.DataFrame(y.sum(axis=0))
    res2 = list(label_num2.value_counts().index.values[0])

    #训练集去掉异常标签后的标签索引
    new_idx = list(set(range(y_raw.shape[1])) - set(move_idx))
    new_idx.sort()
    new_idx =np.array(new_idx)

    print("筛掉异常标签后的数据集的标签数：",y.shape[1])
    # while 1:pass

    return X, y,new_idx



label_count_datasheet = {'bibtex':159 ,'Corel5k':374,
                         'flags':7 ,'rcv1subset1':101 ,
                         'rcv1subset2':101 ,'yahoo-Arts':26 ,
                         'yahoo-Education':33}


resample_ra = 3
dir_datasheet_upper = '../datasheet/'
dir_save_upper = '../saved five fold/'

restresample_th = [2.0, 2.5]
adapt_Ratio = 0.2
Resample_rest_ratio = 1
ratio_Disjunction = 1

# for datasheet in ['birds']:
for datasheet in list(label_count_datasheet.keys()):
    print(datasheet)
    dir_datasheet = os.path.join(dir_datasheet_upper, datasheet, datasheet + '.arff')
    # 加载数据集 X是数据集中的特征矩阵，y是标签矩阵
    if os.path.exists(dir_datasheet):
        X,y=load_from_arff(dir_datasheet, label_count_datasheet[datasheet])
    else:
        dir_datasheet_train = os.path.join(dir_datasheet_upper, datasheet, datasheet + '-train.arff')
        dir_datasheet_test = os.path.join(dir_datasheet_upper, datasheet, datasheet + '-test.arff')
        Xtrain, ytrain = load_from_arff(dir_datasheet_train, label_count_datasheet[datasheet])
        Xtest, ytest = load_from_arff(dir_datasheet_test, label_count_datasheet[datasheet])

        X, y = safe_vstack(Xtest, ytest, Xtrain, ytrain)
        X = ensure_output_format(X, sparse_format='lil', require_dense=False, enforce_sparse=True)

    splits_count = 1

    X,y,new_idx = preprocess(X,y)
    y = labelRemove_largedataset(y)
    X= featureSelection(X)

    for experiment in range(1):
        kf = KFold(n_splits=5, shuffle=True, random_state=experiment)
        kf.split(X, y)
        count = 0
        for train_index, test_index in kf.split(X, y):
            print("一次实验：")
            y_train, y_test = y[train_index], y[test_index]
            # 含有某标签样本数为0的标签的索引，如果存在的话
            while np.flatnonzero(y_train.sum(axis=0) == 0).any():
                # zero_label 0标签的索引向量
                zero_label = np.flatnonzero(y_train.sum(axis=0) == 0)[0]
                movement = np.argwhere(y_test[:, zero_label] == 1)[0][0]

                train_index = np.append(train_index, test_index[movement])
                test_index = np.delete(test_index, movement)
                y_train, y_test = y[train_index], y[test_index]

            while np.flatnonzero(y_test.sum(axis=0) == 0).any():
                samples0_labels_test = np.flatnonzero(y_test.sum(axis=0) == 0)
                N_intrain = sum(y_train)[:, samples0_labels_test]
                N1_intrain_indicator = N_intrain == 1
                only1sample_label = samples0_labels_test[N1_intrain_indicator.A[0]]

                notonly1_label = samples0_labels_test[~N1_intrain_indicator.A[0]]
                if ~notonly1_label.any():
                    break
                idx_intrain = np.flatnonzero((y_train[:, notonly1_label[0]] == 1).A)
                only1_idx = np.argwhere(y_train[:, only1sample_label] == 1)[:, 0]
                for idx in idx_intrain:
                    if idx not in only1_idx:
                        test_index = np.append(test_index, train_index[idx])
                        train_index = np.delete(train_index, idx)
                        y_train, y_test = y[train_index], y[test_index]
                        break
                    if idx == idx_intrain[-1]:
                        raise ValueError(" ")

            X_train, X_test = X[train_index], X[test_index]

            scaler = StandardScaler(with_mean=False)
            scaler.fit(X_train)
            X_train = scaler.transform(X_train)
            X_test = scaler.transform(X_test)

            dir_save = dir_save_upper +'\\IBLbl\\'+ datasheet
            if not os.path.exists(dir_save):
                os.makedirs(dir_save)

            dataname = datasheet + '_' + str(splits_count)

            label_location = 'end'
            save_sparse = True

            filepath = os.path.join(dir_save, dataname + 'train.arff')
            save_to_arff(X_train, y_train, label_location=label_location,
                         save_sparse=save_sparse, filename=filepath)

            # filepath = os.path.join(dir_save, dataname + 'trainRePlus' + str(restresample_th[1]) + 'dj_BR.arff'

            filepath = os.path.join(dir_save, dataname + 'test.arff')
            save_to_arff(X_test, y_test, label_location=label_location, save_sparse=save_sparse, filename=filepath)

            splits_count += 1
