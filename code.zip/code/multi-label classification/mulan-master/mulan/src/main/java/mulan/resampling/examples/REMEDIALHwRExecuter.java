package mulan.resampling.examples;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import mulan.data.InvalidDataFormatException;
import mulan.data.MultiLabelInstances;
import mulan.resampling.HybridMethod;
import mulan.resampling.MLTL;
import mulan.resampling.REMEDIALHwR;
import weka.core.Utils;

public class REMEDIALHwRExecuter {
	
    public static void main(String[] args) {
        try {
        	// e.g. -dir C:/Users/rodolfo/Desktop/workspace/mulan/data/
            String directory = Utils.getOption("dir", args);
        	// e.g. -arff emotions.arff
            String arffFilename = Utils.getOption("arff", args);
            // e.g. -xml emotions.xml
            String xmlFilename = Utils.getOption("xml", args);
            
            String original_filePath = "F:\\pythonProject\\ORMLSMOTE_maozhaoyang\\saved five fold\\" ;
			String dataArray[] = {"birds","scene","enron","yeast","medical","bibtex",
					"Corel5k","flags","rcv1subset1","rcv1subset2","yahoo-Arts","yahoo-Education"};
//            String dataArray[] = {"yahoo-Education"};
			
			for(String da:dataArray) {
				for(int fold = 1;fold <= 5;fold++) {
		            String xmlFile = original_filePath + "xmlfile/" + da+".xml";
					String arrfFile = original_filePath + da + "/" + da + "_" + fold + "train.arff";
					String outputFile = original_filePath + da + "/" + da + "_" + fold + "trainRePlus2.5dj_remedialhwr.arff";
					
					System.out.println("Loading the dataset...");
		    		MultiLabelInstances originalDataset = new MultiLabelInstances(arrfFile, xmlFile);
		    		System.out.println("Resampling the dataset...");
		    		REMEDIALHwR remedialhwr = new REMEDIALHwR(originalDataset, xmlFile, HybridMethod.MLSMOTE);
		    		MultiLabelInstances resampledDataset = remedialhwr.resample();
		    		System.out.println("New number of instances: " + resampledDataset.getNumInstances());
		    		System.out.println("Writing result dataset...");
		    		BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
		    		writer.write(resampledDataset.getDataSet().toString());
		    		writer.flush();
		    		writer.close();
				}
			}
            
        } catch (InvalidDataFormatException ex) {
            Logger.getLogger(LPROSExecuter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(LPROSExecuter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
