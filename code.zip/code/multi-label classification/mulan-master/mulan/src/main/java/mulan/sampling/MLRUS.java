package mulan.sampling;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;

import mulan.data.InvalidDataFormatException;
import mulan.data.MultiLabelInstances;
import weka.core.Attribute;
import weka.core.Instance;

/**
<!-- globalinfo-start -->
* Class implementing the MultiLabel Random Oversampling. For more information, see<br>
* <br>
* Francisco Charte and Antonio Rivera and Maria Jose del Jesus and Francisco Herrera: Addressing imbalance in multilabel classification: Measures and random resampling algorithms. In: Neurocomputing, 2015.
* <br>
<!-- globalinfo-end -->
*
<!-- technical-bibtex-start -->
* BibTeX:
* <pre>
* @article{charte2015addressing,
*  title={Addressing imbalance in multilabel classification: Measures and random resampling algorithms},
*  author={Charte, Francisco and Rivera, Antonio and del Jesus, Maria Jose and Herrera, Francisco},
*  journal={Neurocomputing},
*  volume={163},
*  pages={3--16},
*  year={2015},
*  publisher={Elsevier}
*}
*
* </pre>
* <br>
<!-- technical-bibtex-end -->
*
* @author Rodolfo Miranda Pereira
* @version 2017.11.24
*/
public class MLRUS extends MLRandomSampling {

	public MLRUS(MultiLabelInstances data, String xmlLabels, Double percentage)
			throws InvalidDataFormatException {
		super(data, xmlLabels, percentage);
	}
	
	public MLRUS(MultiLabelInstances data, String xmlLabels)
			throws InvalidDataFormatException {
		super(data, xmlLabels, 0.25);
	}

	@Override
	public MultiLabelInstances resample() throws Exception {
		Double samplesToDelete = getData().getNumInstances() * getPercentage();
		Set<Attribute> labelAttributes = getData().getLabelAttributes();
		getMetrics().calculateIRLbl();
		getMetrics().calculateMeanIR();
		HashMap<Attribute, ArrayList<Instance>> majBags = new HashMap<Attribute, ArrayList<Instance>>(); 
		for (Attribute label : labelAttributes) {
			Double iRLBl = getMetrics().getIRLbl().get(label);
			Double meanIR = getMetrics().getMeanIR();
			if (iRLBl != null && iRLBl < meanIR) { 
				majBags.put(label, getInstancesFromLabel(label));
			}
		}
		Random generator = new Random(System.currentTimeMillis());
		while (samplesToDelete > 0) {
			ArrayList<Attribute> markedToRemove = new ArrayList<Attribute>(); 
			for (Attribute label : majBags.keySet()) {
				ArrayList<Instance> majBag = majBags.get(label);
				int size = majBag.size();
				if (size == 0) {
					markedToRemove.add(label);
					continue;
				}
				int sampleIndex = generator.nextInt(size);
				Instance instanceToDelete = majBag.get(sampleIndex);
				getData().getDataSet().remove(instanceToDelete);
				majBag.remove(instanceToDelete);
				majBags.replace(label, majBag);
				getMetrics().recalcDelSample(instanceToDelete);
				Double newIRLBl = getMetrics().getIRLbl().get(label);
				Double newMeanIR = getMetrics().getMeanIR();
				if (newIRLBl >= newMeanIR) {
					markedToRemove.add(label);
				}
				samplesToDelete--;
				if (samplesToDelete <= 0) {
					break;
				}
			}
			for (Attribute label : markedToRemove) {
				majBags.remove(label);
			}
			if (majBags.size() == 0) {
				samplesToDelete = 0.0;
			}
		}
		return getData(); 
	}
}
