package mulan.sampling;

public enum InstanceType {
	SAFE,
	BORDERLINE,
	RARE,
	OUTLIER,
	MAJORITY
}
