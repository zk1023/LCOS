package mulan.experiments;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.print.attribute.standard.PrinterLocation;

import mulan.classifier.InvalidDataException;
import mulan.classifier.MultiLabelLearner;
import mulan.classifier.ensemble.EnsembleOfSampling;
import mulan.classifier.hypernet.BaseFunction;
import mulan.classifier.lazy.MLkNN;
import mulan.classifier.meta.RAkEL;
import mulan.classifier.transformation.BinaryRelevance;
import mulan.classifier.transformation.COCOA;
import mulan.classifier.transformation.CalibratedLabelRanking;
import mulan.classifier.transformation.ECCRU23;
import mulan.classifier.transformation.LabelPowerset;
import mulan.data.IterativeStratification;
import mulan.data.MultiLabelInstances;
import mulan.evaluation.Evaluation;
import mulan.evaluation.Evaluator;
import mulan.evaluation.MultipleEvaluation;
import mulan.evaluation.measure.AveragePrecision;
import mulan.evaluation.measure.HammingLoss;
import mulan.evaluation.measure.MacroAUC;
import mulan.evaluation.measure.MacroAUCPR;
import mulan.evaluation.measure.MacroFMeasure;
import mulan.evaluation.measure.Measure;
import mulan.evaluation.measure.MicroAUC;
import mulan.evaluation.measure.MicroFMeasure;
import mulan.evaluation.measure.RankingLoss;
import mulan.sampling.MLSMOTE;
import mulan.sampling.MLSOL;
import mulan.sampling.MultiLabelRandomOverSampling;
import mulan.sampling.MutilLabelRandomUnderSampling;
import mulan.sampling.MultiLabelSampling;
import mulan.sampling.NoProcess;
import mulan.sampling.REMEDIAL;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;
import mulan.classifier.transformation.ClassifierChain;
import mulan.classifier.lazy.IBLR_ML;
import mulan.classifier.meta.HOMER;
import mulan.classifier.meta.HierarchyBuilder;
import mulan.classifier.transformation.EnsembleOfClassifierChains;
import mulan.classifier.meta.RAkELd;
import mulan.classifier.transformation.LabelPowerset;
import weka.classifiers.functions.LibSVM;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;

import mulan.resampling.HybridMethod;
import mulan.resampling.MLTL;
import mulan.resampling.REMEDIALHwR;


public class normalizeStrongweak6 {

	public static void main(String[] args) {
		try{

			FileWriter fileWriter = new FileWriter("/home/username/MLL/data/experiments/result_write_all/normalize_strongweak_6/result_write.txt");
			FileWriter fileWriter2 = new FileWriter("/home/username/MLL/data/experiments/result_write_all/normalize_strongweak_6_record/result_write.txt")
			String original_filePath = "/home/username/MLL/data/experiments/saved five fold/" ;
			String filePath = "/home/username/MLL/data/experiments/regroup/train data/";
			
			Classifier cla =  new LibSVM();
			
			BinaryRelevance br1=new BinaryRelevance(cla);
			ClassifierChain cc = new ClassifierChain(cla);
			MLkNN mlknn=new MLkNN(10, 1.0);
			CalibratedLabelRanking clr=new CalibratedLabelRanking(cla);
			EnsembleOfClassifierChains ecc = new EnsembleOfClassifierChains(cla, 10, false, false);
			HOMER homer = new HOMER(new LabelPowerset(cla), 3, HierarchyBuilder.Method.Clustering);
			
			MultiLabelLearner baseLearners[]={br1, cc, mlknn, clr, homer,ecc}; 

			String dataNames[]={"bibtex"};	



			for(String dataName:dataNames){ 
				String xmlFile = "/home/username/MLL/data/experiments/saved five fold/xmlfile/"+dataName+".xml";
				String arrfFile=original_filePath+dataName+"/"+dataName+"_1train.arff";
				
				System.out.println("Loading the data set: "+dataName);
				fileWriter.write("Loading the data set: "+dataName+"\r");
				MultiLabelInstances mldata=new MultiLabelInstances(arrfFile,xmlFile);
				
				MultiLabelInstances multiTrain=null;
				MultiLabelInstances multiTest=null;		
				
				List<Measure> measures = new ArrayList<>(3);
	            measures.add(new MacroFMeasure(mldata.getNumLabels()));
	            measures.add(new MacroAUC(mldata.getNumLabels()));
				
	            System.out.print("Method\t");
	            fileWriter.write("Method\t");
	            for(Measure m:measures){
	            	System.out.print(m.getName()+"\t");
	            	fileWriter.write(m.getName()+"\t");
	            }
	            System.out.println();
	            fileWriter.write("\r");

				for(MultiLabelLearner base:baseLearners){
					
					MLSOL mlsosl=new MLSOL(); mlsosl.setP(0.3);
					NoProcess nosampling=new NoProcess();
					MLSMOTE mlsmote=new MLSMOTE();
					MultiLabelRandomOverSampling mlros = new MultiLabelRandomOverSampling(0.5);
					MutilLabelRandomUnderSampling mlrus = new MutilLabelRandomUnderSampling(0.1);
					
					MLTL mltl = new MLTL(mldata, xmlFile);
		    		REMEDIALHwR remedialhwr = new REMEDIALHwR(mldata, xmlFile, HybridMethod.MLSMOTE);

					MultiLabelSampling samplings[]={nosampling,mlsmote,mlsosl,nosampling,nosampling,mlros,mlrus};

					MultiLabelLearner learners[]={base,base,base,base,base,base,base};
					
		            for(int i=0;i<Math.min(samplings.length, learners.length);i++){
		            	MultiLabelSampling sp=samplings[i];
		            	MultiLabelLearner ml=learners[i];
		            	MultipleEvaluation results = new MultipleEvaluation(mldata);  
		            	int numRepetitions=2, numFlods=5;

						for (int repetition = 0; repetition < numRepetitions; repetition++) {
							for(int fold = 0; fold < numFlods; fold++) {
								String train_arrfFile = original_filePath+dataName+"/"+dataName+"_"+String.valueOf(fold+1)+"train.arff";
								String test_arrfFile = original_filePath+dataName+"/"+dataName+"_"+String.valueOf(fold+1)+"test.arff";

								if(i == 3) {
									train_arrfFile = filePath+dataName+"/"+dataName+"_"+String.valueOf(fold+1)+"trainRePlus2.5dj_compare.arff";
								}
								if(i == 4) {
									train_arrfFile = filePath+dataName+"/"+dataName+"_"+String.valueOf(fold+1)+"trainRePlus2.5dj.arff";
								}
								
								multiTrain = new MultiLabelInstances(train_arrfFile,xmlFile);
								multiTest = new MultiLabelInstances(test_arrfFile,xmlFile);

								Evaluation e1=ftest(sp,ml,multiTrain,multiTest,measures);
		    	            	results.addEvaluation(e1);
		    	            	if(fold == 0) {
		    	            		fileWriter2.write(dataName+"\r");
			    	            	fileWriter2.write(base+"\r");
			    	            	fileWriter2.write(samplings[i]+"\r");
			    	
		    	            	}
		    	            	fileWriter2.write(e1.getMeasures()+"\r");
		    	            	
							}
		    	        }
						StringBuffer sb=new StringBuffer();
						results.calculateStatistics();
						
						if(! sp.getClass().equals(NoProcess.class)){
							sb.append(BaseFunction.Get_Sampling_name(sp)+"_");
						}
						sb.append(BaseFunction.Get_Classifier_name(ml));
						if(ml.getClass().equals(EnsembleOfSampling.class)){
							sb.append("_"+BaseFunction.Get_Sampling_name(((EnsembleOfSampling)ml).getMlsampling())+"_"+BaseFunction.Get_Classifier_name(((EnsembleOfSampling)ml).getBaseLearner()));
						}
						sb.append("\t");
						for(Measure m:measures){
							sb.append(BaseFunction.Round(results.getMean(m.getName()), 4)+"\t");
						}
						sb.append("\n");
						
						System.out.print(sb.toString());
						if(i == (samplings.length - 2)) {
							fileWriter.write(sb.toString());
						}
						if(i == (samplings.length - 1)) {
							fileWriter.write(sb.toString());
						}
						
					}
		        }    
			} 
			fileWriter.close();
			fileWriter2.close();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
		
	
	public static Evaluation ftest(MultiLabelSampling mls, MultiLabelLearner mll, MultiLabelInstances mlTrain,MultiLabelInstances mlTest,List<Measure> measures) throws InvalidDataException, Exception{
		 MultiLabelSampling mlsCopy=mls.makeCopy();
		 MultiLabelLearner mllCopy=mll.makeCopy();
		 MultiLabelInstances mlTrainCopy=mlTrain.clone();
		 MultiLabelInstances mlTestCopy=mlTest.clone();	
		 
		 mllCopy.build(mlsCopy.build(mlTrainCopy));
		 
		 Evaluator evaluator = new Evaluator(); 
		 Evaluation ev = evaluator.evaluate(mllCopy, mlTestCopy, measures);
		 return ev;
	}

}

