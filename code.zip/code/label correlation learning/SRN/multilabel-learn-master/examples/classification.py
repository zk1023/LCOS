import numpy as np
import sys
sys.path.insert(0, "F:\\python\\SRN\\multilabel-learn-master")
import os
import xlwt

from mlearn.models import CSRPE, SRN
from mlearn.utils import load_data

from mlearn.criteria import pairwise_f1_macro, pairwise_f1_micro, pairwise_hamming_loss, sparse_pairwise_f1_score
from prettytable import PrettyTable

import tensorflow as tf

def SRN_example():
    dataSets=["bibtex","Corel5k","flags","rcv1subset1","rcv1subset2",
              "yahoo-Arts","yahoo-Education"]
    data_head = ["dataSet", "train_score", "test_score"]
    experiment_counts = 1  # 实验的次数
    dataSet_counts = len(dataSets)
    model_counts = 10  # 模型种类（原数据训练\过采样数据训练）
    label_nums = [50,50,7,50,50,24,27]
    label_correlation = []
    for lc in range(dataSet_counts):
        label_correlation.append(np.zeros((label_nums[lc], label_nums[lc])))

    for i in range(dataSet_counts):
        for experiment_count in range(1, experiment_counts + 1):
            for model_count in range(1, model_counts + 1):
                suffix = ''
                if model_count == 2:
                    suffix = 'RePlus2.5dj'
                X_train, Y_train = load_data('./data/' + dataSets[i] + '/' + dataSets[i] + '_' + str(experiment_count) + 'train' + suffix,
                                             './data/' + dataSets[i] + '/' + dataSets[i])
                clf = SRN(n_features=X_train.shape[1], n_labels=Y_train.shape[1],
                                 scoring_fn=sparse_pairwise_f1_score)
                clf.train(X_train, Y_train)

                with tf.Session() as sess:
                    sess.run(tf.global_variables_initializer())
                    temp = abs(sess.run(clf.model.weights[3]))

                    for row in range(label_nums[i]):
                        for col in range(label_nums[i]):
                            label_correlation[i][row][col] += temp[row][col]


    for lc in range(dataSet_counts):
        for row in range(label_nums[lc]):
            for col in range(label_nums[lc]):
                label_correlation[lc][row][col] /= experiment_counts

    np.set_printoptions(precision=3,threshold=np.inf , suppress=True)
    for lc in range(dataSet_counts):
        print("数据集：",dataSets[lc])
        print("平均标签关联性：\n",label_correlation[lc])


def main():
    # print("Running CSRPE ...")
    # CSRPE_example()
    print("Running SRN ...")
    SRN_example()


if __name__ == '__main__':
    main()
