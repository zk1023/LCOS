# multilabel-learn: Multilabel-Classification Algorithms

[![Build Status](https://travis-ci.org/yangarbiter/multilabel-learn.svg?branch=master)](https://travis-ci.org/yangarbiter/multilabel-learn)

## Implemented Algorithms

#### Cost-Sensitive Algorithms

* [SRN](mlearn/models/srn/srn.py): mlearn.models.SRN
* [Cost-Sensitive Reference Pair Encoding (CSRPE)](mlearn/models/csrpe.py): mlearn.models.CSRPE
* [Probabilistic Classifier Chains](mlearn/models/probabilistic_classifier_chains.py): mlearn.models.ProbabilisticClassifierChains

#### Other Algorithms

* [Binary Relevance](mlearn/models/srn/binary_relevance.py): mlearn.models.BinaryRelevance
* [Classifier Chains](mlearn/models/srn/classifier_chains.py): mlearn.models.ClassifierChains
* [RAndom K labELsets](mlearn/models/srn/random_k_labelsets.py): mlearn.models.RandomKLabelsets


