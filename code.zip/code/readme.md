
# execution step： #
**1.Preprocess the original data set：** execute file &nbsp; -> &nbsp; `proposed resampling algorithm/preprocess/dataPreprocess.py `

**2.Learn the label correlation of the dataset:**  &nbsp; input the preprocessed training set to learn the label correlation of the dataset.&nbsp; &nbsp; execute file &nbsp; -> &nbsp; `label correlation learning/SRN/multilabel-learn-master/examples/classification.py`

**3.Resampling training set：**Taking the label correlation into account, resampling the preprocessed training set.  &nbsp; &nbsp; execute file &nbsp; -> &nbsp; `proposed resampling algorithm/Resampling and metric rank/ourmethod.py`

**4.Classify the Multi-label dataset：**classify the resampled datasets, and use the published resampling methods to resampling and classify at the same time, finally obtain several metric value of multi-label dataset.&nbsp; &nbsp; execute file &nbsp; -> &nbsp;  `multi-label classification/mulan-master/mulan/src/main/java/mulan/experiments/normalizeStrongweak6.java`

**5.Read the metric value：** &nbsp; &nbsp; execute file &nbsp; -> &nbsp; `proposed resampling algorithm/Resampling and metric rank/result_statistics.py`

**6.Rank the metric value：** &nbsp; &nbsp; execute file &nbsp; -> &nbsp;  `proposed resampling algorithm/Resampling and metric rank/performance - read.py`


# Required environments、installation packages and their versions to perform SRN: #

numpy>=1.17<br>
scipy>=1.3<br>
joblib<br>
Cython>=0.29<br>
six<br>
scikit-learn<br>
liac-arff<br>
pandas<br>
tensorflow<2.0<br>
keras>2.0<br>
tqdm<br>

All data sets are public data sets
All data sets are available at  
Mulan: A Java library for multi-label learning（https://mulan.sourceforge.net/datasets.html）
and https://www.uco.es/kdis/mllresources/




	  
	
	